public class AudioCollage {
    // Returns a new array that rescales a[] by a multiplicative factor of alpha.
    public static double[] amplify(double[] a, double alpha){
        double[] result = new double[a.length];
        for(int i = 0; i < a.length; i++){
            result[i] = alpha * a[i];
        }
        return result;
    }

    // Returns a new array that is the reverse of a[].
    public static double[] reverse(double[] a){

        int n = a.length;
        double[] result = new double[n];
        for(int i = 0; i < n; i++){
            result[i] = a[n - i];
        }
        return result;
    }

    // Returns a new array that is the concatenation of a[] and b[].
    public static double[] merge(double[] a, double[] b){
        assert a.length == b.length;
        int n = a.length;
        double[] result = new double[n];

        for(int i = 0; i < n; i++){
            result[i] = a[i] + b[i];
        }
        return result;
    }

    // Returns a new array that is the sum of a[] and b[],
    // padding the shorter arrays with trailing 0s if necessary.
    public static double[] mix(double[] a, double[] b){
        int n = a.length;
        int m = b.length;
        if (m > n){
            double[] result = new double[m];
            for(int i = 0; i < m; i++){
                if(i<n) {
                    result[i]  = a[i] + b[i];
                }
                else{
                    result[i] = b[i];
                }

            }
            return result;
        }else if (m < n){
            double[] result = new double[n];
            for(int i = 0; i < n; i++){
                if(i < m){
                    result[i] = b[i] + a[i];
                }else
                    result[i] = a[i];
            }
            return result;
        }else{
            double[] result = new double[m];
            for(int i = 0; i < m; i++){
                result[i] = a[i] + b[i];
            }
            return result;
        }

    }

    // Returns a new array that changes the speed by the given factor.
    public static double[] changeSpeed(double[] a, double alpha){
        int n = (int) ( a.length/alpha);
        double[] result = new double[n];
        for(int i = 0; i < n; i++){
            result[i] = a[(int) (i*alpha)];
        }
        return result;
    }

    // Creates an audio collage and plays it on standard audio.
    // See below for the requirements.
    public static void main(String[] args){
        double alpha = Double.parseDouble(args[0]);
        //double alpha = 1.5;

        while(!StdIn.isEmpty()){
            StdOut.println("About to read File");
            double [] a = StdAudio.read(StdIn.readString());
            //double [] b = StdAudio.read(StdIn.readString());
            //double alpha = StdIn.readDouble();
            StdOut.println("Read File");

            StdAudio.play(a);
            double[] b = amplify(a,alpha);
            StdAudio.play(b);
            double [] c = reverse(a);
            StdAudio.play(c);
            double[] bmergeA = merge(a,b);
            StdAudio.play(bmergeA);
            double[] bmixA = mix(a,b);
            StdAudio.play(bmixA);
        }



    }
}
